<template>
	<div class="selectTemplate-content">
		<!-- top navtab切换 -->
		<topSTem></topSTem>
		<!-- 内容框 -->
		<contontSTem></contontSTem>
	</div>
</template>

<script>
	import topSTem from './selectTemplate/topSTem.vue';
	import contontSTem from './selectTemplate/contontSTem.vue';
	import { mapMutations, mapGetters } from 'vuex';
	export default {
		data() {
			return {
			};
		},
		components: {
			topSTem,
			contontSTem
		},
		computed: {
			i18n() {
				return this.$t('navigation');
			},
			...mapGetters(['GET_PUBLISH'])
		},
		created () {
		},
		watch: {
			GET_PUBLISH: {
				handler(a, b) {
				},
				deep: true
			}
		},
		mounted() {},
		beforeDestroy () {
		},
		methods: {
			...mapMutations({
				setMoreSet: 'setMoreSet'
			})
		}
	};
</script>

<style>
</style>
