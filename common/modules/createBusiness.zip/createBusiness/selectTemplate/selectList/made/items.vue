<template>
	<view class="content-items">
		<view class="items-box" @tap='goToTemplatePro'>
			<image :src="product" alt="" class="items-img"></image>
			<div class="items-text">
				<p class="text">新品介绍/活动宣传/企业个人通用</p>
			</div>
			<div class="chaKanOrUser">
				查看104
				<text class="user-text">使用4915</text>
			</div>
		</view>
	</view>
</template>

<script>
	import product from '@/static/mbcImg/publish/createBusiness/rhx2.png';
	import date from '@/static/mbcJs/dateTime.js';
	export default {
	    data () {
			return {
				product: product
			};
	    },
		props: {
			msgData: {
				type: Object
			}
		},
		created() {
		},
		filters: {
          /* 格式化时间戳 */
          dateTime (val) {
            return date.dateTime('.', val);
          }
        },
	    methods: {
			goToTemplatePro() {
				console.log('to投放商机');
				uni.navigateTo({
					url: '/modules/createBusiness/templatePro/templatePro'
				});
			},
	    }
	};
</script>

<style>
	.content-items{
		position: relative;
		width: 690upx;
		margin: 26upx 30upx;
	}
	.items-box{
		position: relative;
		width: 100%;
	}
	.items-img{
		position: relative;
		width: 690upx;
		height: 368upx;
	}
	.items-text{
		position: relative;
		width: 100%;
		padding: 6upx 0 20upx 0;
	}
	.items-text>p{
		ont-family: PingFangSC-Medium;
		font-size: 40upx;
		color: #2E2E30;
		line-height: 60upx;
	}
	.chaKanOrUser{
		position: relative;
		width: 100%;
		font-family: PingFangSC-Regular;
		font-size: 26upx;
		color: #9B9B9B;
		line-height: 13px;
	}
	.user-text{
		position: relative;
		margin-left: 38upx;
	}
</style>