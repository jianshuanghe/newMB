<template>
	<div class="templatePro-content">
		<div class="templatePro">
			<!-- 内容区 -->
			<moduleTemPro
			:statusTemp='statusTemp'
			:sourceTemp='sourceTemp'
			:routeParam='routeParam'
			:moduleDateList='moduleDateList'
			:moduleTempList='moduleTempList'
			:setFixedShow='setFixedShow'
			@tap-ModuleTemPro='tapModuleTemPro'></moduleTemPro>
			<!-- 底部按钮区域 -->
			<moduleBtnPro
			:statusTemp='statusTemp'
			:sourceTemp='sourceTemp'
			:routeParam='routeParam'
			:businessTemList='businessTemList'
			:moduleDateList='moduleDateList'
			:setFixedShow='setFixedShow'
			@tap-ModuleBtnPro='tapModuleBtnPro'></moduleBtnPro>
		</div>
	</div>
</template>

<script>
	import moduleTemPro from './moduleTemPro/moduleTemPro';
	import moduleBtnPro from './moduleBtnPro/moduleBtnPro';
	import { mapMutations, mapGetters } from 'vuex';
	export default {
		name: 'editQualificatCert',
		components: {
			moduleTemPro,
			moduleBtnPro
		},
		data() {
			return {
				setFixedShow: true,
				statusTemp: 1, // 当前模板的状态；0代表：编辑，1代表：预览，2代表，3代表：.....
				sourceTemp: 0, // 从哪里进来的：0代表：模板列表，1代表：，2代表，3代表：.....
				routeParam: {}, // 路由参数；
				businessTemList: null, // 商机信息数据------真实接口数据
				moduleDateList: null, // 当前模板的数据---------此数据是真实接口返回的数据
				moduleTempList: null, // 当前添加模块的数据------此数据是真实接口返回的数据
				moduleCustTempList: null, // 特殊模板下拉去添加模块的数据----此数据真实接口返回
			};
		},
		onLoad (option) {
			// option说明：
			// id: 说明书id,
			// lookUserId: 用户id 选填 谁在看这个说明书 用于用户交互行为
			this.routeParam = option; // 链接上所有参数；
			this.sourceTemp = Number(option.sourceTemp); // 来源
			if (this.sourceTemp === 0) { // 来源模板列表，此处获取模板详情
				this.getBusinessList(); // 拉去商机信息数据
				this.getTempList(option.id); // 根据id拉去模板信息
				this.getModuleTempList(option.id); // 根据id 拉去用户可添加的模块信息
				if (option.id === 65 ) { // 定制模板下需要拉去基本信息用户可添加的模块
					this.getCustModuleTempList(option.id); // 根据id 拉去用户可添加的模块信息
				};
			} else if (this.sourceTemp === 1) { // 来源我的说明书列表，此处获取说明书详情
				this.getInstructionsList(this.routeParam)
			}
		},
		computed: {
			i18n() {
				return this.$t('qualificatCert');
			},
			...mapGetters(['GET_PUBLISH'])
		},
		watch: {
			GET_PUBLISH: {
				handler(a, b) {
				},
				deep: true
			}
		},
		mounted() {},
		beforeDestroy () {
			console.log('页面销毁之前缓存数据更新-----------setImgList、setCaiGouList');
		},
		methods: {
			...mapMutations({}),
			// 拉去模板详情
			getTempList(id){
				let params = {}; // 请求总数居时 参数为空
				if (!uni.getStorageSync('landRegist')) {
					this.landRegistra(); // 判断登录状态
				} else if (uni.getStorageSync('landRegist')) {
					let landRegistLG = JSON.parse(uni.getStorageSync('landRegist')); // 读取缓存的用户信息
					console.log(landRegistLG.user.id);
					uni.showLoading({
						// 展示loading
						title: '加载中'
					});
					uni.request({
						url: this.api2 + '/rest-rp/temp/' + id, //接口地址。
						data: params,
						method: 'GET',
						header: {
							Authorization: 'Bearer ' + landRegistLG.token //将token放到请求头中
						},
						success: response => {
							console.log(response.data, '---------------response.data--------------')
							if (response.data.ret === '200') {
								uni.hideLoading(); // 隐藏 loading
								this.moduleDateList = response.data;
								this.loadEnd = true; // 加载完成
							} else {
								uni.hideLoading(); // 隐藏 loading
								uni.showToast({
									title: '网络开小差了，请稍后重试',
									icon: 'none',
									duration: 1000
								});
							}
						},
						fail: error => {
							uni.hideLoading(); // 隐藏 loading
							uni.showToast({
								title: '网络繁忙，请稍后',
								icon: 'none',
								duration: 1000
							});
							console.log(error, '网络繁忙，请稍后');
						}
					});
				}
			},
			// 在编辑状态拉去当前模板可添加的模块-----不针对特殊模板（例如定制模板有定制信息部分，这里需要再次去拉去相关模块）
			getModuleTempList(id){
				let params = {}; // 请求总数居时 参数为空
				if (!uni.getStorageSync('landRegist')) {
					this.landRegistra(); // 判断登录状态
				} else if (uni.getStorageSync('landRegist')) {
					let landRegistLG = JSON.parse(uni.getStorageSync('landRegist')); // 读取缓存的用户信息
					console.log(landRegistLG.user.id);
					uni.showLoading({
						// 展示loading
						title: '加载中'
					});
					uni.request({
						url: this.api2 + '/rest-rp/temp/selectModulesByTempId?tempId=' + id, //接口地址。
						data: params,
						method: 'GET',
						header: {
							Authorization: 'Bearer ' + landRegistLG.token //将token放到请求头中
						},
						success: response => {
							console.log(response.data, '---------------response.data--------------')
							if (response.data.ret === '200') {
								uni.hideLoading(); // 隐藏 loading
								this.moduleTempList = response.data;
								this.loadEnd = true; // 加载完成
							} else {
								uni.hideLoading(); // 隐藏 loading
								uni.showToast({
									title: '网络开小差了，请稍后重试',
									icon: 'none',
									duration: 1000
								});
							}
						},
						fail: error => {
							uni.hideLoading(); // 隐藏 loading
							uni.showToast({
								title: '网络繁忙，请稍后',
								icon: 'none',
								duration: 1000
							});
							console.log(error, '网络繁忙，请稍后');
						}
					});
				}
			},
			getCustModuleTempList(id){
				let params = {}; // 请求总数居时 参数为空
				if (!uni.getStorageSync('landRegist')) {
					this.landRegistra(); // 判断登录状态
				} else if (uni.getStorageSync('landRegist')) {
					let landRegistLG = JSON.parse(uni.getStorageSync('landRegist')); // 读取缓存的用户信息
					console.log(landRegistLG.user.id);
					uni.showLoading({
						// 展示loading
						title: '加载中'
					});
					uni.request({
						url: this.api2 + '/rest-rp/temp/selectModulesByTempId?custType=1&tempId=' + id, //接口地址。
						data: params,
						method: 'GET',
						header: {
							Authorization: 'Bearer ' + landRegistLG.token //将token放到请求头中
						},
						success: response => {
							console.log(response.data, '---------------response.data--------------')
							if (response.data.ret === '200') {
								uni.hideLoading(); // 隐藏 loading
								this.moduleCustTempList = response.data;
								this.loadEnd = true; // 加载完成
							} else {
								uni.hideLoading(); // 隐藏 loading
								uni.showToast({
									title: '网络开小差了，请稍后重试',
									icon: 'none',
									duration: 1000
								});
							}
						},
						fail: error => {
							uni.hideLoading(); // 隐藏 loading
							uni.showToast({
								title: '网络繁忙，请稍后',
								icon: 'none',
								duration: 1000
							});
							console.log(error, '网络繁忙，请稍后');
						}
					});
				}
			},
			// 拉去说明书详情
			getInstructionsList(option){
				console.log(option, '链接上的参数')
				let params = {}; // 请求总数居时 参数为空
				if (!uni.getStorageSync('landRegist')) {
					this.landRegistra(); // 判断登录状态
				} else if (uni.getStorageSync('landRegist')) {
					let landRegistLG = JSON.parse(uni.getStorageSync('landRegist')); // 读取缓存的用户信息
					console.log(landRegistLG.user.id);
					uni.showLoading({
						// 展示loading
						title: '加载中'
					});
					uni.request({
						url: this.api2 + '/rest-rp/instruc/' + option.id + '?' + "lookUserId=" + option.lookUserId, //接口地址。
						data: params,
						method: 'GET',
						header: {
							Authorization: 'Bearer ' + landRegistLG.token //将token放到请求头中
						},
						success: response => {
							console.log(response.data, '---------------response.data--------------')
							if (response.data.ret === '200') {
								uni.hideLoading(); // 隐藏 loading
								this.moduleDateList = response.data;
								this.loadEnd = true; // 加载完成
							} else {
								uni.hideLoading(); // 隐藏 loading
								uni.showToast({
									title: '网络开小差了，请稍后重试',
									icon: 'none',
									duration: 1000
								});
							}
						},
						fail: error => {
							uni.hideLoading(); // 隐藏 loading
							uni.showToast({
								title: '网络繁忙，请稍后',
								icon: 'none',
								duration: 1000
							});
							console.log(error, '网络繁忙，请稍后');
						}
					});
				}
			},
			// 拉去商机信息详情
			getBusinessList(){
				let params = {}; // 请求总数居时 参数为空
				if (!uni.getStorageSync('landRegist')) {
					this.landRegistra(); // 判断登录状态
				} else if (uni.getStorageSync('landRegist')) {
					let landRegistLG = JSON.parse(uni.getStorageSync('landRegist')); // 读取缓存的用户信息
					console.log(landRegistLG.user.id);
					uni.showLoading({
						// 展示loading
						title: '加载中'
					});
					uni.request({
						url: this.api2 + '/rest-rp/instruc/userInfo?userId=' + landRegistLG.user.id, //接口地址。
						data: params,
						method: 'GET',
						header: {
							Authorization: 'Bearer ' + landRegistLG.token //将token放到请求头中
						},
						success: response => {
							console.log(response.data, '---------------response.data--------------')
							if (response.data.ret === '200') {
								uni.hideLoading(); // 隐藏 loading
								this.businessTemList = response.data;
								this.loadEnd = true; // 加载完成
							} else {
								uni.hideLoading(); // 隐藏 loading
								uni.showToast({
									title: '网络开小差了，请稍后重试',
									icon: 'none',
									duration: 1000
								});
							}
						},
						fail: error => {
							uni.hideLoading(); // 隐藏 loading
							uni.showToast({
								title: '网络繁忙，请稍后',
								icon: 'none',
								duration: 1000
							});
							console.log(error, '网络繁忙，请稍后');
						}
					});
				}
			},
			// 用户操作模板之后返回的新数据
			tapModuleTemPro (e) {
				console.log(e, '用户操作模板之后返回的新数据');
				this.moduleDateList = e;
			},
			// 用户操作按钮之后返回的新数据
			tapModuleBtnPro (e) {
				console.log(e, '用户操作按钮之后返回的新数据');
				this.setFixedShow = e.setFixedShow; // 处理fixed定位从父原则遮挡问题
				this.statusTemp = e.statusTemp; // 当前模板的状态；0代表：编辑，1代表：预览，2代表，3代表：.....
				this.sourceTemp = e.sourceTemp; // 从哪里进来的：0代表：模板列表，1代表：，2代表，3代表：.....
				// this.moduleDateList = e.moduleDateList; // 当前模板的数据---------此数据是真实接口返回的数据
			},
		}
	};
</script>

<style>
	.templatePro-content{
		position: relative;
		width: 100%;
	}
	.templatePro{
		position: relative;
		width: 100%;
	}
</style>
