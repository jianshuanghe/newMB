
var Static = 'https://style.iambuyer.com/mbc/'; // 静态资源地址
var dImg  = 'https://style.iambuyer.com/imbc/mbcImg/common/MBC.png'; // 默认图片地址
var origin = 'https://so.iambuyer.com';

export {Static, dImg, origin};