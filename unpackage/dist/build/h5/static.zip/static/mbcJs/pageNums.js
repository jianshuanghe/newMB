function pageNums (str) {
	return Math.ceil(str / 8);
}

export {pageNums};