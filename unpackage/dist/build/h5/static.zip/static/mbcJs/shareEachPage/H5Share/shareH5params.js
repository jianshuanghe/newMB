// var origin = location.origin;
var shareH5params = {
    shareTitle: '陌拜', // 分享标题
    shareIntro: '陌拜一下，每天都有新商机', // 分享文字介绍
    shareImg: 'https://style.iambuyer.com/img/shareimg.png', // 分享图片
    shareLink: 'http://so.iambuyer.com' // 分享链接
};

export {
  shareH5params
};
