let madeParams={
	"instrucId":null,
	"userId":null,
	"orderSpMoney": 0, // 商品价格
	"orderYfMoney": 0, // 运费
	"orderDjMoney": 0, // 单价
	"orderSpCount": 0, // 数量
	"receivPcode":"",
	"receivCcode":"",
	"receivAcode":"",
	"receivName":"",
	"receivUser":"",
	"receivPhone":"",
	"expressPcode":"",
	"expressCcode":"",
	"expressAddr": "",
	"orderUnit":"",
	"orderType":"",
	"orderContent":"",
	"isFlow":"",
	"advertPlatform":"",
	"isBanner":"",
	"context":{
		  "custModules":[]
	}
}
export{madeParams}